create function st_bandisnodata(rast raster, forcechecking boolean) returns boolean
    immutable
    strict
    parallel safe
    language sql
as
$$
SELECT public.ST_bandisnodata($1, 1, $2)
$$;

comment on function st_bandisnodata(raster, boolean) is 'args: rast, forceChecking=true - Returns true if the band is filled with only nodata values.';

alter function st_bandisnodata(raster, boolean) owner to postgres;

