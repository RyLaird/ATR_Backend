create function st_clip(rast raster, geom geometry, nodataval double precision[] DEFAULT NULL::double precision[], crop boolean DEFAULT true) returns raster
    immutable
    parallel safe
    language sql
as
$$
SELECT public.ST_Clip($1, NULL, $2, $3, $4)
$$;

alter function st_clip(raster, geometry, double precision[], boolean) owner to postgres;

