create function st_band(rast raster, nbands text, delimiter character DEFAULT ','::bpchar) returns raster
    immutable
    strict
    parallel safe
    language sql
as
$$
SELECT  public.ST_band($1, regexp_split_to_array(regexp_replace($2, '[[:space:]]', '', 'g'), E'\\' || array_to_string(regexp_split_to_array($3, ''), E'\\'))::int[])
$$;

comment on function st_band(raster, text, char) is 'args: rast, nbands, delimiter=, - Returns one or more bands of an existing raster as a new raster. Useful for building new rasters from existing rasters.';

alter function st_band(raster, text, char) owner to postgres;

