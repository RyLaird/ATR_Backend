create function _drop_raster_constraint_nodata_values(rastschema name, rasttable name, rastcolumn name) returns boolean
    strict
    language sql
as
$$
SELECT  public._drop_raster_constraint($1, $2, 'enforce_nodata_values_' || $3)
$$;

alter function _drop_raster_constraint_nodata_values(name, name, name) owner to postgres;

