create function addrasterconstraints(rasttable name, rastcolumn name, VARIADIC constraints text[]) returns boolean
    strict
    language sql
as
$$
SELECT public.AddRasterConstraints('', $1, $2, VARIADIC $3)
$$;

comment on function addrasterconstraints(name, name, text[]) is 'args: rasttable, rastcolumn, VARIADIC constraints - Adds raster constraints to a loaded raster table for a specific column that constrains spatial ref, scaling, blocksize, alignment, bands, band type and a flag to denote if raster column is regularly blocked. The table must be loaded with data for the constraints to be inferred. Returns true if the constraint setting was accomplished and issues a notice otherwise.';

alter function addrasterconstraints(name, name, text[]) owner to postgres;

