create function raster_geometry_contain(raster, geometry) returns boolean
    immutable
    strict
    parallel safe
    language sql
as
$$
select $1::public.geometry ~ $2
$$;

alter function raster_geometry_contain(raster, geometry) owner to postgres;

