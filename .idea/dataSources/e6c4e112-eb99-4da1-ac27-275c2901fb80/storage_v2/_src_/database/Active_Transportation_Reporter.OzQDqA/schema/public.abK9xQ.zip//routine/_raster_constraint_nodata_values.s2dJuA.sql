create function _raster_constraint_nodata_values(rast raster) returns numeric[]
    immutable
    strict
    parallel safe
    language sql
as
$$
SELECT array_agg(round(nodatavalue::numeric, 10))::numeric[] FROM public.ST_BandMetaData($1, ARRAY[]::int[]);
$$;

alter function _raster_constraint_nodata_values(raster) owner to postgres;

