create function st_intersection(rast1 raster, rast2 raster, nodataval double precision) returns raster
    immutable
    parallel safe
    language sql
as
$$
SELECT public.st_intersection($1, 1, $2, 1, 'BOTH', ARRAY[$3, $3])
$$;

alter function st_intersection(raster, raster, double precision) owner to postgres;

