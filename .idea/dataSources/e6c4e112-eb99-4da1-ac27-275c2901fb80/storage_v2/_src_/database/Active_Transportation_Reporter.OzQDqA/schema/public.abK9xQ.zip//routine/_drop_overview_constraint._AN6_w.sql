create function _drop_overview_constraint(ovschema name, ovtable name, ovcolumn name) returns boolean
    strict
    language sql
as
$$
SELECT  public._drop_raster_constraint($1, $2, 'enforce_overview_' || $3)
$$;

alter function _drop_overview_constraint(name, name, name) owner to postgres;

